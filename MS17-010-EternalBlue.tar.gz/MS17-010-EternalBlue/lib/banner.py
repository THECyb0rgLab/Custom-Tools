#!/usr/bin/python
# -*- coding: utf-8 -*- 
import logger,sys
sys.path.insert(0, 'lib/')

def show(mode):
	print(logger.RED(''))
	print(logger.RED('███╗   ███╗███████╗ ██╗███████╗       ██████╗  ██╗ ██████╗ ...Se4ng_Y - (_TheCyb0rg_)_%s' % logger.RED(mode)))
	print(logger.RED('████╗ ████║██╔════╝███║╚════██║      ██╔═████╗███║██╔═████╗'))
	print(logger.RED('██╔████╔██║███████╗╚██║    ██╔╝█████╗██║██╔██║╚██║██║██╔██║'))
	print(logger.RED('██║╚██╔╝██║╚════██║ ██║   ██╔╝ ╚════╝████╔╝██║ ██║████╔╝██║'))
	print(logger.RED('██║ ╚═╝ ██║███████║ ██║   ██║        ╚██████╔╝ ██║╚██████╔╝'))
	print(logger.RED('╚═╝     ╚═╝╚══════╝ ╚═╝   ╚═╝         ╚═════╝  ╚═╝ ╚═════╝ '))
	print(logger.RED(''))
